package pro.Jsp.Servlet.jatl;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ProductServlet  extends HttpServlet{

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<Product> products = fechProductsFromDataBase();
		req.setAttribute("products", products);
		
		req.getRequestDispatcher("/productList.jsp").forward(req, resp);
	}

	
	
	private ArrayList<Product> fechProductsFromDataBase() {
		ArrayList<Product> products= new ArrayList<>();
		
		products.add(new Product(1,"product 1", 10.88));
		products.add(new Product(2,"product 2", 20.88));
		products.add(new Product(3,"product 3", 30.88));
		
		return products;
	}
}
