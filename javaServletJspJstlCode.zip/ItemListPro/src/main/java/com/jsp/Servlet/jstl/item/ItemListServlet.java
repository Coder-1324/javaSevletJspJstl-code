package com.jsp.Servlet.jstl.item;

import java.io.IOException;
import java.util.ArrayList;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ItemListServlet  extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		ArrayList<String> items= new ArrayList<>();
		items.add("item 1");
		items.add("item 2");
		items.add("item 3");
		
		req.setAttribute("items", items);
		
		req.getRequestDispatcher("/itemList.jsp").forward(req, resp);
	}

}
