package product.list.srvlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class productSevlet extends HttpServlet
{
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {
		List<product> products = new ArrayList<>();
		
		request.setAttribute("products",products);
		
		RequestDispatcher dispatcher = request.getRequestDispatcher("/product-list.jsp");
		
		dispatcher.forward(request, resp);
	}

}
