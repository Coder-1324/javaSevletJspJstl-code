package product.list.srvlet;

public class product {
	
	private int id;
	private String name;
	private double price;
	

}
