package com.serv.jsp.Jstl;

import java.io.IOException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class UserServlet  extends HttpServlet{
	private UserService userService;
	
	@Override
	public void init() throws ServletException {
		super.init();
		userService = new UserService();
	}
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		List<User> users = userService.getAllusers();
		
		req.getRequestDispatcher("/userList.jsp").forward(req, resp);
	}

}
