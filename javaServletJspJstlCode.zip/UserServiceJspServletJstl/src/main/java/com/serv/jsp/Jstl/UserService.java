package com.serv.jsp.Jstl;

import java.util.ArrayList;
import java.util.List;



public class UserService {
	public List<User>getAllUsers(){
		List<User> users = new ArrayList<>();
		users.add(new User(1,"Nikhil","Chopde"));
		users.add(new User(2,"Virat","Kohli"));
		users.add(new User(1,"Ram","Singh"));
		
		return users;
	}

}
